# FCC offline workflow core v0.1

Python 3.10+; verified with Python 3.12.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m labflow --workspace data/demo demo --out exports/demo
```

Open docs/fcc/pipeline_usage.md for Korean instructions and MCP setup. Adjust workspace paths in examples/mcp_servers.json when moving to another computer. The enclosed demo/ report is synthetic and DRAFT; its thresholds are fictional software fixtures.

This archive contains the common offline core, its 41 workflow/transport tests and a synthetic report. It does not contain the separate equipment registry/database, actual FCC/KDB/standard originals, live instrument drivers or official release capabilities. The full workspace suite additionally tests the equipment registry (48 total). Collect source documents using the separate agent_collection_request.zip.

GitHub collaboration: https://github.com/hctinno/DEVICE/tree/codex/fcc-lab-foundation . Use the branch for current code and data; user file transfer is optional. See materials/README.md.
